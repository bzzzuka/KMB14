#include <iostream>
#include <iomanip>
#include <cmath>
#include "nr.h"

using namespace std;

// Driver for routine powell

DP func(Vec_I_DP &x)               // функции, которые прогоняются
{
    //return 0.5-NR::bessj0(SQR(x[0]-1.0)+SQR(x[1]-2.0)+SQR(x[2]-3.0));
    //return 0.5-NR::bessj0((x[0]-1.0) - SQR(x[1]-2.0));
    //return SQR(x[0])+SQR(x[1])+SQR(x[2]);
    //return 4*SQR(x[0]-1) + SQR(x[1]-6);
    return SQR(x[0]*x[0])-SQR(x[0])+1;      // x[0] - первая переменная , x[1] - вторая и так далее
    
}

DP Powell(int *a, DP func(Vec_I_DP &x), int NDIM, int n){    // n количество точек, NDIM размерность , а - массив,который делится на точки
    int m = 1;
    int k = 0;
    DP MIN_VAL = 100000; // минимум функции
    
    for( k=0; k<n*NDIM; k = k+NDIM){
        cout << "Точка номер " << m << " : " ;
        m++;
        for(int j=0; j<NDIM; j++){
            a[k+j] = k+j ;              // массив а произвольный {0,1,2,3,...}
            cout << a[k+j] << " " ;
        }
        cout << endl;
        
        
        const DP FTOL=1.0e-6;
        DP p_d[NDIM];    // массив под точку
        
        
        for(int p = 0; p < NDIM; p++){
            p_d[p] = a[k+p]; //приравниваем значения из массива a
        }
        cout << endl;
        int i,j,iter;
        DP fret;
        Vec_DP p(p_d,NDIM);
        Mat_DP xi(NDIM,NDIM);
        
        for (i=0;i<NDIM;i++)
            for (j=0;j<NDIM;j++)
                xi[i][j]=(i == j ? 1.0 : 0.0);
        NR::powell(p,xi,FTOL,iter,fret,func);
        cout << "Iterations: " << iter << endl << endl;
        cout << "Minimum found at: " << endl;
        cout << fixed << setprecision(6);
        for (i=0;i<NDIM;i++) cout << setw(12)  << p[i];
        cout << endl << endl << "Minimum function value = ";
        cout << setw(12) << fret << endl << endl;
        
        if(fret < MIN_VAL){ MIN_VAL = fret;}
        }
    cout << "Глобальный минимум : " << MIN_VAL << endl ;
    return MIN_VAL;
}

int main(void)
{
    int n = 2; // количество точек
    const int NDIM=1; // размерность
    int *a = new int[n*NDIM];   // массив точек n*NDIM
    
    for(int k=0; k<n*NDIM; k = k+NDIM){
        for(int j=0; j<NDIM; j++){
            a[k+j] = k+j ;              // массив а произвольный {0,1,2,3,...}
        }
    }
    
    Powell(a, func, NDIM, n);       // вызов функции 
    
       return 0;
}
